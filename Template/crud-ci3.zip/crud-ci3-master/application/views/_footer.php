		</div>
		<div class="footer">
			Copyright 2017 - yukcoding.id
		</div>
	</div>
</body>
</html>